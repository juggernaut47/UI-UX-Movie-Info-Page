# Interstellar — Mini Movie Site
Basic two‑file setup:
- `index.html`
- `css/movie.css`

Drop poster/background & cast images into `images/` using the names already referenced or update the `<img src>` paths.

Meets your brief:
- Dark cinematic theme
- Google Fonts (Bebas Neue + Montserrat)
- Rounded cards with soft shadows
- Flexbox/Grid for cast and reviews
- Responsive layout
- CSS‑only star ratings via the `.stars[data-rating="X"]` attribute

Tip: Replace the placeholder platform links under “Where to Watch” with your region’s links.
